local hosting for the webapp - the scripts cover dependencies

If on MACOS or LINUX, run the BASH.sh version

If on Windows, run the WIN.ps1 version

For readme on files, see inside src
